<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Sesi 2</title>
</head>

<body>

    <?php
    // menampilkan session
    echo "Username : " . $_SESSION["username"] . "<br>";
    echo "Nama : " . $_SESSION["nama"];
    ?>

</body>

</html>