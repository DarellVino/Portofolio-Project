<?php
function jumlah($a, $b)
{
    return $a + $b;
}

function kurang($a, $b)
{
    return $a - $b;
}

function kali($a, $b)
{
    return $a * $b;
}

function bagi($a, $b)
{
    if ($b == 0) {
        return "Tidak bisa dibagi 0";
    }
    return $a / $b;
}

function sisa_bagi($a, $b)
{
    if ($b == 0) {
        return "Tidak bisa mod 0";
    }
    return $a % $b;
}

if (!isset($_POST['bil1']) || !isset($_POST['bil2'])) {
    header("Location: form_hitung.php");
    exit;
}

$bil1 = $_POST['bil1'];
$bil2 = $_POST['bil2'];
$aksi = $_POST['hitung'];

if ($aksi == "jumlah") {
    $hasil = jumlah($bil1, $bil2);
    $ket = "Penjumlahan";
} elseif ($aksi == "kurang") {
    $hasil = kurang($bil1, $bil2);
    $ket = "Pengurangan";
} elseif ($aksi == "Kali") {
    $hasil = kali($bil1, $bil2);
    $ket = "Perkalian";
} elseif ($aksi == "Bagi") {
    $hasil = bagi($bil1, $bil2);
    $ket = "Pembagian";
} elseif ($aksi == "Sisa Bagi") {
    $hasil = sisa_bagi($bil1, $bil2);
    $ket = "Sisa Bagi";
} else {
    $hasil = "Tidak valid";
    $ket = "-";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hasil Hitung</title>
</head>
<body>

<p>Hasil : <?= $hasil ?></p>

<br>
<a href="tugas_form_hitung.php">Kembali</a>

</body>
</html>