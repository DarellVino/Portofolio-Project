<!DOCTYPE html>
<html>

<head>
    <title>Registrasi Peserta</title>
</head>

<body>

    <h2>Registrasi Peserta Kursus</h2>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"> <!--action="htmlspecialchars($_SERVER["PHP_SELF"])": Ini memastikan setelah tombol simpan diklik, data diproses di halaman yang sama. Penggunaan htmlspecialchars berfungsi untuk mencegah serangan keamanan (XSS).-->
        <table>
            <tr>
                <td>Nama:</td>
                <td><input type="text" name="nama" size="30"></td>
            </tr>
            <tr>
                <td>E-mail:</td>
                <td><input type="email" name="email" size="30"></td>
            </tr>
            <tr>
                <td valign="top">Nama Kursus:</td>
                <td>
                    <input type="checkbox" name="kursus[]" value="C#"> C# (biaya Rp.1.000.000,-)<br>
                    <input type="checkbox" name="kursus[]" value="JavaScript"> JavaScript (biaya Rp.500.000,-)<br>
                    <input type="checkbox" name="kursus[]" value="Perl"> Perl (biaya Rp.800.000,-)<br>
                    <input type="checkbox" name="kursus[]" value="PHP"> PHP (biaya Rp.1.100.000,-)<br>
                </td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td><input type="submit" name="submit" value="Simpan"></td>
            </tr>
        </table>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
        $nama = $_POST['nama'];
        $email = $_POST['email'];
        $kursus_pilihan = isset($_POST['kursus']) ? $_POST['kursus'] : [];

        $kosong = [];

        if (empty(trim($nama))) {
            $kosong[] = "nama belum diisi!";
        }
        if (empty(trim($email))) {
            $kosong[] = "email belum diisi!";
        }
        if (empty(($kursus_pilihan))) {
            $kosong[] = "kursus belum dipilih!";
        }
        if (!empty($kosong)) {
            echo "<br><b>Data yang belum diisi:</b>";
            echo "<ul>";
            foreach ($kosong as $error) {
                echo "<li>$error</li>";
            }
            echo "</ul>";
        } else {
            $daftar_harga = [
                "C#" => 1000000,
                "JavaScript" => 500000,
                "Perl" => 800000,
                "PHP" => 1100000
            ];

            $total_biaya = 0;
            foreach ($kursus_pilihan as $item) {
                $total_biaya += $daftar_harga[$item];
            }

            echo "<hr>";
            echo "Terimakasih data anda telah diterima.<br>";
            echo "Kursus yang anda pilih sebanyak " . count($kursus_pilihan) . " buah yaitu:";
            echo "<ul>";
            foreach ($kursus_pilihan as $pilihan) {
                echo "<li>$pilihan</li>";
            }
            echo "</ul>";
            echo "Biaya kursus sebesar Rp. " . number_format($total_biaya, 0, ',', '.') . ",-";
        }
    }
    ?>

</body>

</html>