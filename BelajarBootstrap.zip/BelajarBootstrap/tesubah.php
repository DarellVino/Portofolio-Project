<?php

include('crudmhs.php');

$nim = "133110001";
$nama = "Agus Setiawan";
$kelamin = "L";
$jurusan = "TI";

$hasil = ubahMhs($nim, $nama, $kelamin, $jurusan);

if ($hasil == true) {

    echo "Berhasil";
} else {

    echo "Error";
}
