<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Data barang</h1>
    <hr style="border: 1px solid black;">
    <form action="output.php" method="post">
    Nama Barang  : <br>
    <input type="text" name="nama"><br>

    Jenis Barang : <br>
    <select name="jenis" id="" class="dropdown"><br>
       <option value="">--Pilih--</option>
       <option value="PC">PC Komputer</option>
       <option value="LP">Laptop</option>
       <option value="PR">Printer</option>
       <option value="SP">Smartphone</option>
       <option value="IP">I-Pad</option><br>
</select><br>

Nomor seri : <br>
<input type="text" name="seri"><br>

Merk : <br>
<input type="text" name="merk"><br>

Negara Pembuat : <br>
<input type="text" name="negara"><br>

<fieldset style="width : 20%">
    <legend>Tanggal pembuatan</legend>
       Tanggal
        <select name="tgl">
        <?php
      for($hari= 1; $hari<= 31; $hari++){
          $htgl = str_pad($hari, 2, "0", STR_PAD_LEFT);
          echo "<option value='$htgl'>$htgl</option>";
      }
    ?>
</select>
    Bulan
    <select name="bln">
    <?php
      for($bulan=1; $bulan<=12; $bulan++){
          $hbln = str_pad($bulan, 2, "0", STR_PAD_LEFT);
          echo "<option value='$hbln'>$hbln</option>";
      }
    ?>
    </select>
    Tahun
    <select name="thn">
    <?php
        $tahun_sekarang = date("Y");
        $tahun_awal = $tahun_sekarang - 10;
        $tahun_akhir = $tahun_sekarang + 10;
        for($tahun=$tahun_akhir;$tahun>=$tahun_awal;$tahun--){
        echo "<option value='$tahun'>$tahun</option>";
        }
    ?>
        </select>
    </fieldset>
        Harga : <br>
        Rp. <input type="number" name="harga"><br>

        Jumlah Stok : <br>
        <input type="number" name="stok"><br>

        <hr style="border: 1px solid black;">
    <input type="submit" value="SUBMIT">
    <input type="reset" value="RESET">
    
</form>
</body>
</html>