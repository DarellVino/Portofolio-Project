<!DOCTYPE html>
<html>

<head>
    <title>Tambah Mahasiswa</title>
</head>

<body>

    <h2>Tambah Data Mahasiswa</h2>

    <form method="post"
        action="prosestambah.php">

        <table>

            <tr>
                <td>NIM</td>
                <td>
                    <input type="text" name="nim">
                </td>
            </tr>

            <tr>
                <td>Nama</td>
                <td>
                    <input type="text" name="nama">
                </td>
            </tr>

            <tr>
                <td>Jenis Kelamin</td>

                <td>

                    <input type="radio"
                        name="kelamin"
                        value="L">Laki-laki

                    <input type="radio"
                        name="kelamin"
                        value="P">Perempuan

                </td>
            </tr>

            <tr>
                <td>Jurusan</td>

                <td>

                    <select name="jurusan">

                        <option value="TI">TI</option>
                        <option value="SI">SI</option>
                        <option value="MI">MI</option>
                        <option value="TK">TK</option>
                        <option value="KA">KA</option>

                    </select>

                </td>
            </tr>

            <tr>
                <td></td>

                <td>
                    <input type="submit"
                        value="Tambah">
                </td>
            </tr>

        </table>

    </form>

</body>

</html>