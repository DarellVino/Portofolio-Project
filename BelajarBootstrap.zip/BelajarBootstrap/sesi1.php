<?php
// memulai sesi
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Sesi 1</title>
</head>

<body>

    <?php
    // Set variabel sesi
    $_SESSION["username"] = "ika";
    $_SESSION["nama"] = "Kartika Fatmawati";

    echo "Variabel sesi telah diciptakan.";
    ?>

</body>

</html>