<?php
$data = [
    ["Vino", "Matematika", 85, "B"],
    ["Orva", "Informatika", 70, "C"],
    ["Saverio", "Matematika", 80, "B"],
    ["Radit", "Bahasa Inggris", 95, "A"],
    ["Dede", "Informatika", 75, "C"],
    ["Asep", "Bahasa Inggris", 90, "A"]
];

$pilih = isset($_GET['mapel']) ? $_GET['mapel'] : "Semua";

$total = 0;
$jumlah = 0;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Nilai</title>
    <style>
        body {
            font-family: Arial;
        }
        select {
            margin: 15px;
            padding: 4px;
        }
        table {
            border-collapse: collapse;
            width: 70%;
            margin: center;
        }
        th, td {
            border: 1px solid #aaa;
            padding: 8px;
            text-align: auto;
        }
        th {
            background-color: #ddd;
        }
        
        .gradeA {
            background-color: #5ce47cbc; /* hijau muda */
        }
        .gradeB {
            background-color: #efd16ff6; /* kuning muda */
        }
        .gradeC {
            background-color: #f07680d8; /* merah muda */
        }
        .gradeD {
            background-color: #7b7b87; /* abu muda */
        }

        .rata {
            background-color: #ffffff;
            font-weight: bold;
        }
    </style>
</head>
<body>

<form method="GET">
    Pilih mapel : <br/>
     <select name="mapel" onchange="this.form.submit()"> 
        <option <?= $pilih=="Semua"?"selected":"" ?>>Semua</option> 
        <option <?= $pilih=="Matematika"?"selected":"" ?>>Matematika</option>
        <option <?= $pilih=="Informatika"?"selected":"" ?>>Informatika</option>
        <option <?= $pilih=="Bahasa Inggris"?"selected":"" ?>>Bahasa Inggris</option>
    </select>
</form>

<table>
    <table width="400" border="1">
    <tr>
        <th>Nama</th> <br/>
        <th>Mapel</th>
        <th>Nilai</th>
        <th>Grade</th>
    </tr>
    <?php
     foreach($data as $d): ?>
        <?php
         if($pilih == "Semua" || $d[1] == $pilih): ?>
        <?php
            if($d[3] == "A") $warna = "gradeA";
            elseif($d[3] == "B") $warna = "gradeB";
            elseif($d[3] == "C") $warna = "gradeC";
            else $warna = "gradeD";
        ?>

        <tr class="<?= $warna; ?>">
            <td><?= $d[0]; ?></td>
            <td><?= $d[1]; ?></td>
            <td><?= $d[2]; ?></td>
            <td><?= $d[3]; ?></td>
        </tr>

        <?php 
            $total += $d[2];
            $jumlah++;
        endif; ?>
    <?php 
         endforeach; ?>

    <?php 
    if($jumlah > 0): ?>
    <tr class="rata">
        <td colspan="2">Rata-rata Nilai</td>
        <td colspan="2"><?= number_format($total/$jumlah,2); ?></td>
    </tr>
    <?php 
         endif; ?>

</table>
</body>
</html>