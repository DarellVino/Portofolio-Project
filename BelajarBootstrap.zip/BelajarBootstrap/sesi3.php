<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Sesi 3</title>
</head>

<body>

    <?php
    // mengubah session
    $_SESSION["nama"] = "Kartika Sari";

    echo "Variabel sesi telah diubah.";
    ?>

</body>

</html>