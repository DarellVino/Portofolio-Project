<!DOCTYPE html>
<html>

<head>
    <title>Tambah Matakuliah</title>
</head>

<body>

    <h2>Tambah Matakuliah</h2>

    <form action="prosestambahmk.php" method="POST">

        Kode :
        <input type="text" name="kode">
        <br><br>

        Nama :
        <input type="text" name="nama">
        <br><br>

        SKS :
        <input type="number" name="sks">
        <br><br>

        <button type="submit">
            Simpan
        </button>

    </form>

</body>

</html>