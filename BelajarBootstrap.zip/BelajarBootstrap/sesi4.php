<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Sesi 4</title>
</head>

<body>

    <?php
    // menghapus session
    session_unset();
    session_destroy();
    ?>

    Sesi telah dihapus

</body>

</html>