<!DOCTYPE html>
<html>
<head>
    <title>Form Hitung</title>
</head>
<body>

<h2>HITUNG BILANGAN</h2>

<form action="tugas_hitung.php" method="post">
    Bilangan 1 : <input type="number" name="bil1" required><br><br>
    Bilangan 2 : <input type="number" name="bil2" required><br><br>

    <input type="submit" name="hitung" value="jumlah">
    <input type="submit" name="hitung" value="kurang">
    <input type="submit" name="hitung" value="Kali">
    <input type="submit" name="hitung" value="Bagi">
    <input type="submit" name="hitung" value="Sisa Bagi">
</form>

</body>
</html>