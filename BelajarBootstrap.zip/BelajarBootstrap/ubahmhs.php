<?php

require 'crudmk.php';

if(!isset($_GET["kode"])) {

    die("Kode tidak ditemukan");

}

$kode = $_GET["kode"];

$data = cariMtKuliah($kode);

if(!$data) {

    die("Data tidak ditemukan");

}

?>

<!DOCTYPE html>
<html>

<head>
    <title>Ubah Matakuliah</title>
</head>

<body>

<h2>Ubah Matakuliah</h2>

<form action="prosesubahmk.php" method="POST">

<input type="hidden"
       name="kode"
       value="<?= $data['kode']; ?>">

<table>

<tr>

    <td>Kode</td>
    <td>:</td>
    <td><?= $data['kode']; ?></td>

</tr>

<tr>

    <td>Nama</td>
    <td>:</td>

    <td>

        <input type="text"
               name="nama"
               value="<?= $data['nama']; ?>">

    </td>

</tr>

<tr>

    <td>SKS</td>
    <td>:</td>

    <td>

        <input type="number"
               name="sks"
               value="<?= $data['sks']; ?>">

    </td>

</tr>

<tr>

    <td></td>
    <td></td>

    <td>

        <button type="submit">
            Ubah
        </button>

    </td>

</tr>

</table>

</form>

</body>
</html>