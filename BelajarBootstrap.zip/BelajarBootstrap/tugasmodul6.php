<?php
function celciusKelvin($c)
{
    return $c + 273.15;
}

function celciusFahrenheit($c)
{
    return (1.8 * $c) + 32;
}

if (!isset($_POST['celcius'])) {
    header("Location: form_hitungmodul6.php");
    exit;
}

$celcius = (float) $_POST['celcius'];

$kelvin = celciusKelvin($celcius);
$fahrenheit = celciusFahrenheit($celcius);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hasil Konversi Suhu Celcius Ke Kelvin dan Fahrenheit</title>
</head>
<body>

<h2>HASIL KONVERSI Suhu Celcius ke Kelvin dan Fahrenheit</h2>

<p>Derajat Celcius : <?= $celcius ?> °C</p>
<p>Derajat Kelvin : <?= $kelvin ?> K</p>
<p>Derajat Fahrenheit : <?= $fahrenheit ?> °F</p>

<br>
<a href="form_hitungmodul6.php">Kembali</a>

</body>
</html>
