<?php

include('crudmhs.php');

$nim = '133110001';

$hasil = carimhs($nim);

if ($hasil != null) {

    echo "NIM : " . $hasil['nim'] . "<br>";
    echo "Nama : " . $hasil['nama'] . "<br>";
    echo "Kelamin : " . $hasil['kelamin'] . "<br>";
    echo "Jurusan : " . $hasil['jurusan'] . "<br>";
} else {

    echo "Tidak ada data";
}
